player_manager.AddValidModel( "GOT: Jon Snow", "models/player/got_jonsnow.mdl" )

player_manager.AddValidHands( "GOT: Jon Snow", "models/player/got_jonsnow_hands.mdl", 0, "0" )